
module Main(main) where
import ScannerExp(runScanner)

main :: IO ()
main = runScanner